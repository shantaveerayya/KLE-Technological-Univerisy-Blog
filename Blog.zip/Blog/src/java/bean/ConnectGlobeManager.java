/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author guruvyasa includes all utility functions to get topics, questions,
 * answers etc.
 */
public class ConnectGlobeManager {

    static ArrayList<Answer> getAnswersForQuestion(int id) {
        ArrayList<Answer> answers = new ArrayList<>();
        try {
            Connection con = ConnectionProvider.getCon();

            PreparedStatement ps = con.prepareStatement("select * from answer where question_id = ?");
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                answers.add(new Answer(rs.getInt("user_id"), rs.getString("text")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return answers;
    }

    public static ArrayList<Topic> getTopics() {
        ArrayList<Topic> topics = new ArrayList<>();
        try {
            Connection con = ConnectionProvider.getCon();

            PreparedStatement ps = con.prepareStatement("select * from topic");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                topics.add(new Topic(rs.getInt("id"), rs.getString("name")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return topics;
    }

    public static ArrayList<Question> getQuestionsInTopic(String topicName) {
        /**
         * returns: arraylist of question objects given a topic name
         */
        ArrayList<Question> questions = new ArrayList<>();
        try {
            Connection con = ConnectionProvider.getCon();

            PreparedStatement ps = con.prepareStatement("select q.id,q.text,t.name,q.user_id,q.type,q.image_url,q.likes from question q,topic t where q.topic_id = t.id and t.name like '%" + topicName + "%' and deleted = 0");
//            ps.setString(1, topicName);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String[] text = rs.getString("text").split("#");
                questions.add(new Question(rs.getInt("id"), text[0], text[1], rs.getString("name"), rs.getInt("user_id"), rs.getString("type"),rs.getString("image_url"), rs.getInt("likes")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return questions;

    }

    public static ArrayList<Question> getQuestions(String type, String userId, String requester) {
        /**
         * returns: arraylist of question objects given a topic name
         */

        PreparedStatement ps;
        ArrayList<Question> questions = new ArrayList<>();
        try {
            Connection con = ConnectionProvider.getCon();
            if (type.equals("public")) {
                ps = con.prepareStatement("select q.id,q.text,t.name,q.user_id,q.type from question q,topic t where q.topic_id = t.id and q.type='" + type + "'");
            } else {
                if (requester.equals("admin")) {
                    ps = con.prepareStatement("select q.id,q.text,t.name,q.user_id,q.type from question q,topic t where q.topic_id = t.id and q.type='" + type + "'");
                } else {
                    ps = con.prepareStatement("select q.id,q.text,t.name,q.user_id,q.type from question q,topic t where q.topic_id = t.id and q.type='" + type + "' and q.user_id = " + userId);
                }
            }
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String[] text = rs.getString("text").split("#");

                questions.add(new Question(rs.getInt("id"), text[0], text[1], rs.getString("name"), rs.getInt("user_id"), rs.getString("type")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return questions;

    }

    public static ArrayList<Question> getQuestions() {
        /**
         * returns: arraylist of question objects given a topic name
         */

        PreparedStatement ps;
        ArrayList<Question> questions = new ArrayList<>();
        try {
            Connection con = ConnectionProvider.getCon();

            ps = con.prepareStatement("select q.id,q.text,t.name,q.user_id,q.type,q.image_url,q.likes from question q,topic t where q.topic_id = t.id and deleted = 0");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String[] text = rs.getString("text").split("#");

                questions.add(new Question(rs.getInt("id"), text[0], text[1], rs.getString("name"), rs.getInt("user_id"), rs.getString("type"), rs.getString("image_url"), rs.getInt("likes")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return questions;

    }
    
    
    public static boolean likeQuestion(String questionId) {
        /**
         * returns: arraylist of question objects given a topic name
         */

        PreparedStatement ps;

        try {
            Connection con = ConnectionProvider.getCon();

            ps = con.prepareStatement("update question q set q.likes = q.likes+1 where q.id = "+questionId);
            
            ps.executeUpdate();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            
        }
        return false;

    }

    public static boolean deleteQuestion(String questionId) {
        /**
         * returns: arraylist of question objects given a topic name
         */

        PreparedStatement ps;

        try {
            Connection con = ConnectionProvider.getCon();

            ps = con.prepareStatement("update question q set q.deleted = 1 where q.id = "+questionId);
            
            ps.executeUpdate();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            
        }
        return false;

    }

    static String getAuthorFromId(int id) {
        String authorName = null;
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("select * from user where id = " + id);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                authorName = rs.getString("name");
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return authorName;
    }

    static void saveQuestion(String questionText, int topicId, int authorId) {

    }
}
