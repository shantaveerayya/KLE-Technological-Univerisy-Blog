/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;



/**
 *
 * 
 */

@MultipartConfig
public class SaveQuestion extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet SaveQuestion</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet SaveQuestion at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String filename;
      
        HttpSession session = request.getSession();
        if (session.getAttribute("id") == null) {
            response.sendRedirect("login.jsp");
        }
        int userId = Integer.valueOf(session.getAttribute("id").toString());
        String type;
        try{
        }
        catch(Exception e){
            type="public";
        }
//        System.out.println("*****type is: "+type);

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            try {
                			
			
			System.out.println("second");
                        
                           Part p1 = request.getPart("file");
            InputStream is = p1.getInputStream();

            // read filename which is sent as a part
//            Part p2 = request.getPart("photoname");
//            Scanner s = new Scanner(p2.getInputStream());
//            String filename = s.nextLine();    // read filename from stream
            filename = Paths.get(p1.getSubmittedFileName()).getFileName().toString(); // MSIE fix.
            String abs_filename;
            abs_filename = "D:\\uploads\\"+filename;
//            System.out.println(fileName);
            
            File file = new File(abs_filename);
//            System.out.println(file.getAbsolutePath());
            FileOutputStream os = new FileOutputStream(file);

            // write bytes taken from uploaded file to target file
            int ch = is.read();
            while (ch != -1) {
                os.write(ch);
                ch = is.read();
            }
            os.close();
				
			//file copy
                                 String title = request.getParameter("title");
        System.out.println(title);
        String question = request.getParameter("question");
        int topicId = Integer.valueOf(request.getParameter("topic"));
                    type= request.getParameter("msg_status").toString();

                Connection con = ConnectionProvider.getCon();
                PreparedStatement ps = con.prepareStatement("insert into question(text,user_id,topic_id,type,image_url) values(?,?,?,?,?)");
                ps.setString(1, title+"#"+question);
                ps.setInt(2, userId);
                ps.setInt(3, topicId);
                ps.setString(4, (type.equals("off"))?"private":"public");
                ps.setString(5, filename);


                ps.executeUpdate();
                session.setAttribute("status", "Question saved successfully");

            } catch (Exception e) {
                e.printStackTrace();
                session.setAttribute("status", "There was an error saving the question");

            }
            response.sendRedirect("writeArticle.jsp");
        }

    

    }
    
}
