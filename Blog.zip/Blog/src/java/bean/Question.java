/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.ArrayList;

/**
 *
 *
 */
public class Question {
    private ArrayList<Answer> answers = new ArrayList<>();
    private int id;
    private String title;
    private String text;
    private String authorName;

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }
    private String topicName;
    private String type;
    private String imageUrl;
    private int likes;
    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    public String getTopic(){
        return topicName;
    }
    
    public String getType(){
        return type;
    }
    
    public void setType(String type){
        this.type = type;
    }
    
    public String getAuthor(){
        return authorName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public String getTitle() {
        return title;
    }
    public void setText(String text) {
        this.text = text;
    }
    
    public boolean isPrivate(){
        return type.equals("private");
    }
    public Question(int id, String text, String topicName,int authorId,String type) {
        this.id = id;
        this.text = text;
        this.topicName = topicName;
        this.authorName = ConnectGlobeManager.getAuthorFromId(authorId);
        this.type = type;
        this.setAnswers();
    }

    public Question(int id, String title, String text, String topicName,int authorId, String type) {
        this.id = id;
        this.title = title;
        this.text = text;
        this.topicName = topicName;
        this.authorName = ConnectGlobeManager.getAuthorFromId(authorId);
        this.type = type;
        this.setAnswers();
    }
    
    public Question(int id, String title, String text, String topicName,int authorId, String type,String image_url, int likes) {
        this.id = id;
        this.title = title;
        this.text = text;
        this.topicName = topicName;
        this.authorName = ConnectGlobeManager.getAuthorFromId(authorId);
        this.type = type;
        this.imageUrl = image_url;
        this.likes = likes;
        this.setAnswers();
    }
    private void setAnswers(){
        this.answers = ConnectGlobeManager.getAnswersForQuestion(id);
    }
    public ArrayList<Answer> getAnswers(){
        return this.answers;
    }
    
}
