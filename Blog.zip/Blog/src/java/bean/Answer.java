/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

/**
 *
 *
 */
public class Answer {
    private String author;
    private int id;
    private String text;

    public int getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Answer(int id, String text){
        this.id = id;
        this.text = text;
        this.author = getAuthorFromId(id);
    }
    
    private String getAuthorFromId(int id){
        return ConnectGlobeManager.getAuthorFromId(id);
    }
    
    public String getAuthor(){
        return author;
    }
}
