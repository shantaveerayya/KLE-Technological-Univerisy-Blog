package bean;
import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * 
 */
public class RegistrationDao {



	public static boolean register(CustomerBean customerBean){
		try{
			Connection con=ConnectionProvider.getCon();
			PreparedStatement ps = con.prepareStatement("insert into user(name,address,phone_number,username,password,user_type) values(?,?,?,?,?,?)");
			ps.setString(1,customerBean.getName());
                        ps.setString(2,customerBean.getAddress());
                        ps.setString(3,customerBean.getPhoneNumber());
                        ps.setString(4,customerBean.getUsername());
                        ps.setString(5,customerBean.getPassword());
                        ps.setString(6,customerBean.getUserType());

			ps.executeUpdate();
			return true;
			
		}catch(Exception e){
                    e.printStackTrace();
                    return false;
                }
		
	}
        
        public static String getUsername(LoginBean bean){
            return bean.getPass();
        }
}

    
