package bean;
import java.sql.*;
public class LoginDao {

	public static int validate(LoginBean bean){
		int cust_id=-1;
		try{
			Connection con=ConnectionProvider.getCon();
			
			PreparedStatement ps=con.prepareStatement("select * from user where username=? and password=?");
			ps.setString(1,bean.getUsername());
                       
			ps.setString(2, bean.getPass());
			
			ResultSet rs=ps.executeQuery();
			rs.next();
                        return rs.getInt("id");
			
		}catch(Exception e){
                    
                }
		return cust_id;
	}
        
        public static String getUsername(LoginBean bean){
            return bean.getPass();
        }
}
